// SPDX-License-Identifier: MIT
/*
 * Copyright (c) 2025 HiSilicon Technologies Co., Ltd. All rights reserved.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 */

#include <ctype.h>
#include <stddef.h>
#include <fcntl.h>
#include <dirent.h>
#include <errno.h>
#include <unistd.h>

#include "./common/u_utool_error.h"
#include "./common/u_utool_common.h"
#include "./feature/u_utool_io_die.h"
#include "u_utool_dispatch.h"
#include "u_utool_pkt.h"

#define UTOOL_INVALID_FD (-1)

enum utool_dev_step_flag {
	UTOOL_DEV_STEP_SCAN = 0,
	UTOOL_DEV_STEP_LS,
	UTOOL_DEV_STEP_UMMU,
	UTOOL_DEV_STEP_DEBUGFS,
};

static void utool_help(void)
{
	utool_info_msg("Usage: ubctl <-c ${chip_id}> <-d ${ub_ctl_id}> <-m ${module}>\n"
		       "       [-f ${function}] [-p ${port}] [-e ${value}] [-u ${ummu_id}] [-i ${index}]\n"
		       "       [-t ${time}] [-dev ${device}] [-file ${file}] [-h] [ls]\n\n"
		       "options:\n\n"
		       "  -c $chip_id: chip id, chip id and ub ctl id  are used to find the valid device.\n\n"
		       "  -d $ub_ctl_id : ub ctl id, chip id and ub ctl id  are used to find the valid device.\n\n"
		       "  -m $module: module name, current module include: dl, nl, ta, tp, ba, qos, msgq,\n\n"
		       "              ummu, port_info, ubommu, ecc_2b, queue, uboe, dump,\n"
		       "              port_pkt_stats, fw_version, port_link, debugfs.\n\n"
		       "  -f $function: function name, different processing functions are provided for each module.\n"
		       "                dl: pkt_stats, lane, link_status, bit_err, bist, bist_err, link_trace,\n"
		       "                    performance, rt_bandwidth, perf\n"
		       "                nl: pkt_stats, abn_stats, ssu_stats, ssu_sw, ssu_oq, ssu_p2p, ssu_vl_pkt\n"
		       "                ta: pkt_stats, abn_stats, wqe_processing_time\n"
		       "                tp: pkt_stats, abn_stats, scc_version, scc_log, scc_debug_en, rx_bank,\n"
		       "                    route_result\n"
		       "                ba: pkt_stats, mar, mar_perf, ub_mem_decoder, inter_sp_rout, inter_mp_rout,\n"
		       "                    intra_sp_rout, intra_mp_rout, port_scna, port_table, port_wb_table,\n"
		       "                    mar_cyc_en\n"
		       "                msgq: que_stats, entry\n"
		       "                ummu: ummu_sync_query, ummu_sync_config\n"
		       "                uboe: rxmac2txmac, txmac2rxmac, txpcs2rxpcs, prbs, prbs_err_cnt\n\n"
		       "  -p $port: port index, indicates the physical port index,\n"
		       "            The port_bitmap represents each bit as a port, used in the dl-performance\n"
		       "            and rt_bandwidth command.\n\n"
		       "  -e $value: value, used to set the value of the register.\n\n"
		       "  -u $ummu_id: ummu id, it is used to search for the corresponding ummu register,\n"
		       "               the value of ummu_id is the same as the number of io_die, the io_ide with\n"
		       "               a smaller absolute address corresponds to a smaller ummu_id index.\n\n"
		       "  -i $index: entry index, indicates the index of entry.\n\n"
		       "  -t $time: time, used to query mar_perf statistics.\n"
		       "            period, used to query port performance.\n\n"
		       "  -dev $device: device name, can be entered: Bus_Num / Device_Name / NetDev_Name.\n\n"
		       "  -file $file: file name, the specific file name queried by debugfs.\n\n"
		       "  -h: help. display the help information, also use -h or --help or help or -help.\n\n"
		       "  ls: querying information about all chip.\n\n"
		       "example:\n\n"
		       "   ubctl -m dl -p 0 -f bit_err -d 0 -c 0       query the number of bit errors by port\n\n"
		       "   ubctl -m ba -p 0 -f pkt_stats -d 0 -c 0     query BA packet statistics\n\n");
}

static void utool_close(struct utool_dev *dev)
{
	if (dev->fd >= 0) {
		close(dev->fd);
		dev->fd = UTOOL_INVALID_FD;
	}
}

static int utool_open(struct utool_dev *dev)
{
	char *resolved_path = NULL;

	dev->fd = UTOOL_INVALID_FD;
	resolved_path = realpath(dev->devname, NULL);
	if (resolved_path == NULL) {
		utool_err_msg("Failed to resolve the devname, errno = %d.\n", errno);
		return UTOOL_ERR;
	}

	dev->fd = open(resolved_path, O_RDWR);
	if (dev->fd < 0) {
		utool_err_msg("Please insmod ub_fwctl.ko and make sure the device file exists, errno = %d.\n", errno);
		UTOOL_FREE(resolved_path);
		return UTOOL_ERR;
	}

	UTOOL_FREE(resolved_path);
	return UTOOL_OK;
}

static FILE *utool_open_file(const char *file_path, const char *mode)
{
	char *resolved_path = NULL;
	FILE *fp = NULL;

	resolved_path = realpath(file_path, NULL);
	if (resolved_path == NULL) {
		utool_err_msg("Failed to get realpath, errno = %d.\n", errno);
		return NULL;
	}
	fp = fopen(resolved_path, mode);
	UTOOL_FREE(resolved_path);
	return fp;
}

static int utool_check_ubase_device(char *file_path, char *dev_name)
{
#define UTOOL_UB_ENTITY_NAME_STR "UB_ENTITY_NAME"
#define UTOOL_UBASE_DRIVER "ubase"
#define UTOOL_DRIVER_STR "DRIVER"

	char line[UTOOL_LINE_BUF_LEN];
	char *tmp_con = NULL;
	char *token = NULL;
	int ret = UTOOL_OK;
	char *con = NULL;
	FILE *fp = NULL;

	fp = utool_open_file(file_path, "r");
	if (fp == NULL) {
		utool_err_msg("Failed to open the device file.\n");
		return UTOOL_ERR;
	}

	while (fgets(line, UTOOL_LINE_BUF_LEN, fp) != NULL) {
		token = strtok(line, "=");
		if ((token == NULL) || ((con = strtok(NULL, "")) == NULL)) {
			continue;
		}

		tmp_con = strtok(con, "\n");
		if ((strcmp(token, UTOOL_DRIVER_STR) == 0) &&
		    (strcmp(tmp_con, UTOOL_UBASE_DRIVER) != 0)) {
			utool_warn_msg("The device is not ubase device, type = %s.\n", tmp_con);
			(void)fclose(fp);
			return UTOOL_ERR;
		}

		if (strcmp(token, UTOOL_UB_ENTITY_NAME_STR) == 0) {
			ret = snprintf(dev_name, UTOOL_DEV_NAME_LEN_MAX, "%s", tmp_con);
			if (ret <= 0 || ret >= UTOOL_DEV_NAME_LEN_MAX) {
				utool_err_msg("Failed to format dev name, errno = %d, ret = %d.\n", errno, ret);
				(void)fclose(fp);
				return UTOOL_ERR;
			}
			(void)fclose(fp);
			return UTOOL_OK;
		}
	}

	(void)fclose(fp);
	utool_err_msg("Failed to find ubase device.\n");

	return UTOOL_ERR;
}

static int utool_excute_io_die(struct utool_dev *dev)
{
	struct utool_cmd_param cmd_param = {};

	if (utool_open(dev) != UTOOL_OK) {
		return UTOOL_ERR;
	}

	if (utool_io_die_cmd(dev, &cmd_param) != UTOOL_OK) {
		utool_close(dev);
		utool_err_msg("Failed to query port info , errno = %d.\n", errno);
		return UTOOL_ERR;
	}
	utool_close(dev);

	return UTOOL_OK;
}

static int utool_proc_excption_dev(uint32_t chip_id, uint32_t die_id, enum utool_dev_step_flag step_flag)
{
	if (step_flag == UTOOL_DEV_STEP_LS) {
		utool_reg_msg("\ntotal ubctl count: %u\n", utool_get_ubctl_id());
		return UTOOL_OK_LS;
	}

	if (step_flag == UTOOL_DEV_STEP_SCAN) {
		utool_err_msg("Ubctl device not found. chip_id = %u, die_id = %u\n", chip_id, die_id);
	} else {
		utool_err_msg("Ubctl device not found\n");
	}
	return UTOOL_ERR;
}

#define UTOOL_FWCTL_PATH "/dev/fwctl"
static int utool_format_dev_path(struct utool_dev *dev, char *driver_path, struct dirent *entry)
{
#define UTOOL_SYS_CLASS_PATH "/sys/class/fwctl"
#define UTOOL_DEV_UEVENT_NAME "device/uevent"

	int ret;

	ret = snprintf(driver_path, UTOOL_DEV_NAME_LEN_MAX, UTOOL_SYS_CLASS_PATH "/%s/" UTOOL_DEV_UEVENT_NAME,
		       entry->d_name);
	if (ret <= 0 || ret >= UTOOL_DEV_NAME_LEN_MAX) {
		utool_err_msg("Failed to format driver path, errno = %d, ret = %d.\n", errno, ret);
		return UTOOL_ERR;
	}

	ret = snprintf(dev->devname, UTOOL_DEV_NAME_LEN_MAX, UTOOL_FWCTL_PATH "/%s", entry->d_name);
	if (ret <= 0 || ret >= UTOOL_DEV_NAME_LEN_MAX) {
		utool_err_msg("Failed to format fwctl dev name, errno = %d, ret = %d.\n", errno, ret);
		return UTOOL_ERR;
	}

	return UTOOL_OK;
}

static int utool_process_device_info(struct fwctl_rpc_ub_out *out)
{
	struct fwctl_pkt_dev_info_match *dev_info_match;

	dev_info_match = (struct fwctl_pkt_dev_info_match *)out->data;
	if (dev_info_match->is_matched) {
		return UTOOL_OK;
	}

	return UTOOL_ERR;
}

static int utool_check_dev_info(struct utool_dev *dev, uint32_t chip_id, uint32_t die_id)
{
	uint32_t pkt_in_len = sizeof(struct fwctl_pkt_dev_info_match);
	struct utool_pkt_exec pkt_exec = {
		.rpc_cmd = UTOOL_CMD_QUERY_DEV_INFO,
		.data_len = sizeof(struct fwctl_pkt_dev_info_match),
		.execute = utool_process_device_info
	};
	struct fwctl_pkt_dev_info_match pkt_in_match = {
		.chip_id = chip_id,
		.die_id = die_id,
		.is_matched = false,
	};

	return utool_pkt_operation(dev, &pkt_in_match, pkt_in_len, &pkt_exec);
}

static int utool_process_step(struct utool_dev *dev, uint32_t chip_id, uint32_t die_id,
			      enum utool_dev_step_flag step_flag)
{
	int ret = UTOOL_OK;

	if (step_flag == UTOOL_DEV_STEP_LS) {
		if (utool_excute_io_die(dev) != UTOOL_OK) {
			utool_err_msg("Failed to query port bitmap.\n");
		}
		return UTOOL_ERR;
	}

	if (utool_open(dev) != UTOOL_OK) {
		return UTOOL_ERR;
	}

	if (step_flag == UTOOL_DEV_STEP_SCAN) {
		ret = utool_check_dev_info(dev, chip_id, die_id);
		if (ret != UTOOL_OK) {
			utool_close(dev);
		}
	}

	return ret;
}

static int utool_open_dev_step(struct utool_dev *dev, uint32_t chip_id, uint32_t die_id,
			       enum utool_dev_step_flag step_flag)
{
	char driver_path[UTOOL_DEV_NAME_LEN_MAX] = {};
	char ub_entity_name[UTOOL_DEV_NAME_LEN_MAX] = {};
	struct dirent *entry = NULL;
	DIR *class_dir = NULL;
	int ret = UTOOL_OK;

	if ((class_dir = opendir(UTOOL_FWCTL_PATH)) == NULL) {
		utool_err_msg("Failed to open dir %s, errno = %d.\n", UTOOL_FWCTL_PATH, errno);
		return UTOOL_ERR;
	}

	while ((entry = readdir(class_dir)) != NULL) {
		if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
			continue;
		}

		ret = utool_format_dev_path(dev, driver_path, entry);
		if (ret != UTOOL_OK) {
			utool_err_msg("Failed to format dev name.\n");
			(void)closedir(class_dir);
			return ret;
		}

		if (utool_check_ubase_device(driver_path, ub_entity_name) != UTOOL_OK) {
			utool_warn_msg("Ubctl device: %s not ubase device\n", entry->d_name);
			continue;
		}

		ret = utool_process_step(dev, chip_id, die_id, step_flag);
		if (ret != UTOOL_OK) {
			continue;
		}

		(void)closedir(class_dir);

		return UTOOL_OK;
	}
	(void)closedir(class_dir);
	return utool_proc_excption_dev(chip_id, die_id, step_flag);
}

static int utool_check_arg(int argc, char **argv)
{
	char *argv_ptr = NULL;
	char argv_value = ' ';
	size_t argv_len = 0;
	size_t j = 0;
	int i = 0;

	for (i = 1; i < argc; i++) {
		if (strchr(argv[i], '\0') == NULL) {
			utool_err_msg("The input parameter is not string.\n");
			return UTOOL_ERR;
		}

		argv_len = strlen(argv[i]);
		if (argv_len > UBCTL_FILE_NAME_MAX_LEN) {
			utool_err_msg("The input param length = %zubytes is bigger than maximum %ubytes.\n",
				      argv_len, UBCTL_FILE_NAME_MAX_LEN);
			return UTOOL_ERR;
		}

		argv_ptr = argv[i];
		for (j = 0; j < argv_len; j++) {
			argv_value = argv_ptr[j];
			if ((isalnum(argv_value) == 0) && argv_value != '_' && argv_value != '-') {
				utool_err_msg("The input parameter is illegal string.\n");
				return UTOOL_ERR;
			}
		}
	}

	return UTOOL_OK;
}

static int utool_main_parse_sub(int argc, char **argv, struct utool_dev *dev)
{
#define UBCTL_ARG_MIN_NUM 2

	int ret = UTOOL_OK;

	do {
		if (argc < UBCTL_ARG_MIN_NUM) {
			ret = UTOOL_ERR_INVALID_PARAM;
			break;
		}

		ret = utool_check_arg(argc, argv);
		if (ret != UTOOL_OK) {
			break;
		}

		if (strcmp(argv[1], "ls") == 0) {
			return utool_open_dev_step(dev, 0, 0, UTOOL_DEV_STEP_LS);
		}

		if ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "--help") == 0) ||
		    (strcmp(argv[1], "help") == 0) || (strcmp(argv[1], "-help") == 0)) {
			ret = UTOOL_ERR_HELP;
			break;
		}

		ret = utool_parse_command(argc, argv);
		if (ret != UTOOL_OK) {
			utool_err_msg("Failed to parse command.\n");
			break;
		}
	} while (0);

	if (ret != UTOOL_OK) {
		utool_help();
	}

	return ret;
}

int main(int argc, char *argv[])
{
	const struct utool_cmd_param *cmd_param = NULL;
	struct utool_dev dev = {};
	int ret = UTOOL_OK;

	ret = utool_main_parse_sub(argc, argv, &dev);
	if (ret != UTOOL_OK) {
		return ret == UTOOL_OK_LS ? UTOOL_OK : ret;
	}

	cmd_param = utool_get_cmd_param();
	if (cmd_param == NULL) {
		utool_err_msg("Failed to get cmd param.\n");
		return UTOOL_ERR;
	}

	if (cmd_param->module_id == UTOOL_MODULE_NAME_UMMU) {
		ret = utool_open_dev_step(&dev, 0, 0, UTOOL_DEV_STEP_UMMU);
	} else if (cmd_param->module_id == UTOOL_MODULE_NAME_DEBUGFS) {
		dev.fd = UTOOL_INVALID_FD; // debugfs does not need to open dev.
	} else {
		ret = utool_open_dev_step(&dev, cmd_param->chip_id, cmd_param->die_id,
					  UTOOL_DEV_STEP_SCAN);
	}

	if (ret != UTOOL_OK) {
		return ret;
	}

	ret = utool_cmd_select(&dev);

	utool_close(&dev);

	return ret;
}
